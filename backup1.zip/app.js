// server.js

const express = require('express');
const { connectToWhatsApp } = require('./whatsappModule');
const { handleMessage } = require('./Message');
const path = require('path');

const app = express();
const port = 3000;

let qrCodeImage = null;
let isAuthenticated = false;

app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.render('qr', { qrCodeImage });
});

app.get('/dashboard', (req, res) => {
    if (isAuthenticated) {
        res.render('dashboard');
    } else {
        res.redirect('/');
    }
});

async function startWhatsAppConnection() {
    await connectToWhatsApp((sock, message) => handleMessage(sock, message), (update) => {
        const { connection, qrCodeImage: qr } = update;
        if (connection === 'open') {
            isAuthenticated = true;
            qrCodeImage = null;
            setTimeout(() => {
                app.get('/dashboard', (req, res) => {
                    res.render('dashboard');
                });
            }, 1000);
        } else if (qr) {
            qrCodeImage = qr;
        }
    });
}

startWhatsAppConnection().catch(err => console.error('Failed to connect to WhatsApp:', err));

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
